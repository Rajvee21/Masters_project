import {useState} from 'react'
import {Link} from 'react-router-dom'
import LandingIntro from './LandingIntro'

function ResetPassword(){

    return(
        <div className="min-h-screen bg-base-200 flex items-center">
            <div className="card mx-auto w-full max-w-5xl  shadow-xl">
                <div className="grid  md:grid-cols-2 grid-cols-1  bg-base-100 rounded-xl">
                <div className=''>
                        <LandingIntro />
                </div>
                <div className='py-24 px-10'>
                    <h2 className='text-2xl font-semibold mb-2 text-center'>Reset Password</h2>
                    <label className={`label`}>
                        <span className={`label-text`}>New Password</span>
                    </label>
                    <input
                        type="password"
                        placeholder="Password"
                        name="password"
                        required
                        className={`input input-bordered w-full `}
                    />
                    <label className={`label`}>
                        <span className={`label-text`}>Confirm Password</span>
                    </label>
                    <input
                        type="password"
                        placeholder="Password"
                        name="password"
                        required
                        className={`input input-bordered w-full `}
                    />
                    <button type="submit" className={`btn mt-2 w-full btn-primary mt-6`}>Change Password</button>
                    <div className='text-center mt-4'>Don't have an account? <Link to="/register"><span className="  inline-block  hover:text-primary hover:underline hover:cursor-pointer transition duration-200">Register</span></Link></div>
                </div>
            </div>
            </div>
        </div>
    )
}

export default ResetPassword