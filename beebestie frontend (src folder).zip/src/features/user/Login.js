import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import LandingIntro from './LandingIntro';


function Login() {
    const navigate = useNavigate()
    const validationSchema = Yup.object().shape({
        email: Yup.string().email('Please Enter valid email address').required('Email is required'),
        password: Yup.string().required('Password is required'),
    });

    const formik = useFormik({
        initialValues: {
            email: '',
            password: '',
        },
        validationSchema,
        onSubmit: async (values, { setSubmitting, setFieldError }) => {
            try {
                const url = 'http://localhost:3001/auth/login-user';
                const { data: res } = await axios.post(url, values);
                localStorage.setItem('token', res.data.token);
                toast.success('Login successful!');
                navigate('/app/dashboard');
                if (res.data.status === 200) {
                    toast.success(res.data.message);
                    navigate('/app/dashboard');
                } else if (res.data.status === 400) {
                    toast.error(res.data.message);
                }
            } catch (error) {
                if (error.response && error.response.status === 401) {
                    // Invalid email or password
                    toast.error('Invalid email or password. Please try again.');
                } else if (error.response && error.response.status === 404) {
                    // User not found
                    toast.error('User not found. Please check your email and try again.');
                } else {
                    // Other errors
                    toast.error('Wrong password. Try again or click Forgot password to reset it.');
                }
                setSubmitting(false);
            }
        },
    });

    return (
        <div className="min-h-screen bg-base-200 flex items-center">
            <div className="card mx-auto w-full max-w-5xl shadow-xl">
                <div className="grid md:grid-cols-2 grid-cols-1 bg-base-100 rounded-xl">
                    <div className="">
                        <LandingIntro />
                    </div>
                    <div className="py-24 px-10">
                        <h2 className="text-2xl font-semibold mb-2 text-center">Login</h2>
                        <form onSubmit={formik.handleSubmit}>
                            <div className="mb-4">
                                <div className={`form-control w-full mt-4 ${formik.errors.email && formik.touched.email ? 'has-error' : ''}`}>
                                    <label className={`label`}>
                                        <span className={`label-text ${formik.errors.email && formik.touched.email ? 'text-red-500' : ''} `}>Email</span>
                                    </label>
                                    <input
                                        type="email"
                                        placeholder="Email"
                                        name="email"
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        value={formik.values.email}
                                        required
                                        className={`input input-bordered w-full ${formik.errors.email && formik.touched.email ? 'input-error' : ''}`}
                                    />
                                    {formik.errors.email && formik.touched.email && (
                                        <p className="text-xs text-red-500 mt-1">{formik.errors.email}</p>
                                    )}
                                </div>
                                <div className={`form-control w-full mt-4 ${formik.errors.password && formik.touched.password ? 'has-error' : ''}`}>
                                    <label className={`label`}>
                                        <span className={`label-text ${formik.errors.password && formik.touched.password ? 'text-red-500' : ''} `}>Password</span>
                                    </label>
                                    <input
                                        type="password"
                                        placeholder="Password"
                                        name="password"
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                        value={formik.values.password}
                                        required
                                        className={`input input-bordered w-full ${formik.errors.password && formik.touched.password ? 'input-error' : ''}`}
                                    />
                                    {formik.errors.password && formik.touched.password && (
                                        <p className="text-xs text-red-500 mt-1">{formik.errors.password}</p>
                                    )}
                                </div>

                            </div>
                            <div className="text-right text-primary">
                                <Link to="/forgot-password">
                                    <span className="text-sm inline-block hover:text-primary hover:underline hover:cursor-pointer transition duration-200">
                                        Forgot Password?
                                    </span>
                                </Link>
                            </div>
                            <button type="submit" className={`btn mt-2 w-full btn-primary ${formik.isSubmitting ? 'loading' : ''}`}>
                                Login
                            </button>

                            <div className="text-center mt-4">
                                Don't have an account yet?
                                <Link to="/register">
                                    <span className="inline-block hover:text-primary hover:underline hover:cursor-pointer transition duration-200">
                                        Register
                                    </span>
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <ToastContainer />

        </div>
    );
}

export default Login;
