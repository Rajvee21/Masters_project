import React, { useEffect, useState } from 'react';
import moment from 'moment';
import axios from 'axios';
import TrashIcon from '@heroicons/react/24/outline/TrashIcon';

function Leads() {
    const [leads, setLeads] = useState([]);

    useEffect(() => {
        // Fetch data from the API when the component mounts
        axios.get('http://localhost:3001/users/user-list')
            .then((response) => {
                // Extract the 'data' array from the API response
                const leadsData = response.data.data;
                setLeads(leadsData);
            })
            .catch((error) => {
                console.error('Error fetching data:', error);
            });
    }, []);

    // Function to delete a user
    const deleteCurrentUser = (userId) => {
        // Make a DELETE request to the delete user API
        axios
            .delete(`http://localhost:3001/users/delete-user?userId=${userId}`)
            .then(() => {
                // Remove the deleted user from the 'leads' state
                setLeads((prevLeads) => prevLeads.filter((lead) => lead._id !== userId));
            })
            .catch((error) => {
                console.error('Error deleting user:', error);
            });
    };

    return (
        <>
            {/* Leads List in table format loaded from state after API call */}
            <div className="overflow-x-auto w-full">
                <table className="table w-full">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email Id</th>
                            <th>Created At</th>
                            <th>Status</th>
                            <th>Assigned To</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {leads.map((lead, index) => (
                            <tr key={lead._id}>
                                <td>
                                    <div className="flex items-center space-x-3">
                                        <div className="avatar">
                                            <div className="mask mask-squircle w-12 h-12">
                                                {/* Assuming 'profileImage' is the user's avatar */}
                                                <img src={lead.profileImage} alt="Avatar" />
                                            </div>
                                        </div>
                                        <div>
                                            <div className="font-bold">{lead.userName}</div>
                                            <div className="text-sm opacity-50">{lead.email}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>{lead.email}</td>
                                <td>{moment(lead.createdAt).format('DD MMM YY')}</td>
                                <td>{lead.userName}</td>
                                <td>
                                    <button
                                        className="btn btn-square btn-ghost"
                                        onClick={() => deleteCurrentUser(lead._id)}
                                    >
                                        <TrashIcon className="w-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    );
}

export default Leads;
