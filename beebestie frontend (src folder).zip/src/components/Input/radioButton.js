import { useState } from "react"


function RadioBtn({labelTitle,subTitle1,subTitle2, labelStyle, type, containerStyle, defaultValue, updateFormValue, updateType}){

    const [value, setValue] = useState(defaultValue)
    const [selectedOption] = useState('male');


    const updateInputValue = (val) => {
        setValue(val)
        updateFormValue({updateType, value : val})
    }

    return(
        
        <div className={`form-control w-full ${containerStyle}`}>
            <label className="label">
                <span className={"label-text text-base-content " + labelStyle}>{labelTitle}</span>
            </label>
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                    <label className="label">
                        <span className={"label-text text-base-content " + labelStyle}>{subTitle1}</span>
                    </label>
                    <input type={type || "radio"} id="male" name="gender" value="male" checked={selectedOption === value}
onChange={(e) => updateInputValue(e.target.value)} className="radio" />
                </div>
                <div className="flex items-center gap-1">
                    <label className="label">
                        <span className={"label-text text-base-content " + labelStyle}>{subTitle2}</span>
                    </label>
                    <input type={type || "radio"} id="female" name="gender" value="female" checked={selectedOption === value}
 onChange={(e) => updateInputValue(e.target.value)} className="radio" />
                </div>
            </div>
        </div>
    )
}


export default RadioBtn