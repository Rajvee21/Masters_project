import Register from '../features/user/Register'

function ExternalPage(){


    return(
        <div className="">
                <Register />
        </div>
    )
}

export default ExternalPage