
import DocGettingStarted from '../features/documentation/DocGettingStarted'

function ExternalPage(){
    return(
        <div className="">
            <DocGettingStarted />
        </div>
    )
}

export default ExternalPage