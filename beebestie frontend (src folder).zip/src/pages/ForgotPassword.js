
import ForgotPassword from '../features/user/ForgotPassword'

function ExternalPage(){


    return(
        <div className="">
                <ForgotPassword />
        </div>
    )
}

export default ExternalPage