
import Integration from '../../features/integration'

function InternalPage(){
      
    return(
        <Integration />
    )
}

export default InternalPage