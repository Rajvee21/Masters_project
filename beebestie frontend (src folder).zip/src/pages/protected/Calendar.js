
import Calendar from '../../features/calendar'

function InternalPage(){
    return(
        <Calendar />
    )
}

export default InternalPage