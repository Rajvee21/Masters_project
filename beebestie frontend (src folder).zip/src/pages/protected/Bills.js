
import Billing from '../../features/settings/billing'

function InternalPage(){


    return(
        <Billing />
    )
}

export default InternalPage