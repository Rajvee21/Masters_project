
import ResetPassword from '../features/user/ResetPassword'

function ExternalPage(){


    return(
        <div className="">
                <ResetPassword />
        </div>
    )
}

export default ExternalPage